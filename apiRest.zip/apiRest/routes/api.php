<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


 // Usuarios
Route::prefix('usuarios')->group(function() {
   //   Ruta para mostrar usuarios]
     Route::get('/','UsuarioController@index')->name('VerUsuarios');
    /**
     * Ruta para registrar un usuario
     */
    Route::post('/', 'UsuarioController@store')->name('RegistrarUsuario');
});


 // Libros

Route::prefix('libros')->group(function() {

     // Ruta para mostrar libros
    Route::get('/', 'LibroController@index')->name('MostrarLibros');
     // Ruta para registrar un nuevo libro
    Route::post('/', 'LibroController@store')->name('crearLibro');
});


// Prestamos
 // Ruta para mostrar todos los prestamos

Route::get('/pedidos', 'PedidoController@index')->name('obtenerPedidos');


//  Ruta para pedir un libro

Route::post('/pedidos/usuario/{idUser}/libro/{libro_id}', 'PedidoController@pedirLibros')->name('PrestarLibro');


 // Ruta para devolver un libro

Route::put('/entregas/usuario/{idUser}/libro/{libro_id}', 'PedidoController@entregarLibros')->name('DevolverLibro');
