<?php

use App\Libro;
use Illuminate\Database\Seeder;

class LibroTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        Libro::truncate();
        $canBooks = 30;
        factory(App\Libro::class, $canBooks)->create();
    }
}
