<?php

use Illuminate\Database\Seeder;

class PedidoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\Pedido::class, 10)->states('Prestado')->create();
        factory(App\Pedido::class, 10)->states('Regresado')->create();

    }
}
