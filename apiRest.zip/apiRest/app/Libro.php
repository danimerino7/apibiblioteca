<?php

namespace App;

use App\Libro;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class Libro extends Model
{
    use SoftDeletes;


    /**
     * Relationships
     */
    public function pedidos(): object
    {
        return $this->hasMany('App\Pedido', 'pedido_id', 'id');
    }

    /**
     * Obtener todos los libros
     */
    public static function ShowAll()
    {
        return response()->json(['data' => Libro::all()],200);
    }

    /**
     * Crear libro
     */
    public static function registrar($request): array
    {
        try {
            $libro = new self();
            $libro->nombre = $request->nombre;
            $libro->descripcion = $request->descripcion;
            $libro->autor = $request->autor;
            $libro->ejemplares = $request->ejemplares;

            $isSave = $libro->save();
            if($isSave) {
                return [
                    'error' => false,
                    'Libro' => $libro
                ];
            } else {
                return [
                    'error' => true,
                    'mensaje' => 'No se ha podido registrar el libro'
                ];
            }
        } catch (\Throwable $th) {
            return [
                'error' => true,
                'mensaje' => $th->errorInfo
            ];
        }
    }
}
