<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class Usuario extends Model
{
    use SoftDeletes;
    protected $table = 'usuarios';

    /**
     * Relationships
     */
    public function pedidos(): object
    {
        return $this->hasMany('App\Pedido', 'usuario_id', 'id');
    }

    /**
     * Functions
     */
    //mostrar usuarios
    public static function ShowAll()
    {
        return response()->json(['data' => Usuario::all()],200);
    }

    //registrar usuario
    public static function registrar($request): array
    {

        try {
            $usuario = new self;
            $usuario->nombre = $request->nombre;
            $usuario->email = $request->email;
            $cifrar = $request->contraseña;
            $usuario->contraseña = $request->contraseña;
            $isSave = $usuario->save();

            if($isSave) {
                return [
                    'error' => false,
                    'Usuario' =>  $usuario->toArray()
                ];
            } else {
                return [
                    'error' => true,
                    'Usuario' =>  'No se ha podido registrar usuario'
                ];
            }

        } catch (\Throwable $th) {
            return [
                'error' => true,
                'mensaje' => $th->errorInfo
            ];
        }

    }
}
