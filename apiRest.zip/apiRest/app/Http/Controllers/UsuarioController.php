<?php

namespace App\Http\Controllers;

use App\Usuario;
use Illuminate\Http\Request;

class UsuarioController extends Controller
{
    /**
     * Mostrar usuarios
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
       return Usuario::ShowAll();
    }

    /**
     * Registrar usuarios
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return Usuario::registrar($request);
    }
}
