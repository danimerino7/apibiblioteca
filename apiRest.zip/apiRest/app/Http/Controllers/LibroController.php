<?php

namespace App\Http\Controllers;

use App\Libro;
use Illuminate\Http\Request;

class LibroController extends Controller
{
    /**
     * Obtener Libros
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
       return Libro::ShowAll();
    }

    /**
     * Crear Libros
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return Libro::registrar($request);
    }
}
